package com.stackroute.newz.model;

import java.util.Date;

public class News {

	
	/*
	 * This class should have ten fields
	 * (newsId,title,author,description,publishedAt,content,url,urlToImage,Reminder,
	 * NewsSource). This class should also contain the getters and setters for the 
	 * fields along with the no-arg , parameterized	constructor and toString method.
	 * The value of publishedAt should not be accepted from the user but should be
	 * always initialized with the system date.
	 */

	public Reminder getReminder() {
		return null;
	}

	public void setReminder(Reminder reminder) {
		
	}

	public int getNewsId() {
		return 0;
	}

	public void setNewsId(int newsId) {
		
	}

	public String getTitle() {
		return null;
	}

	public void setTitle(String title) {

	}

	public String getAuthor() {
		return null;
	}

	public void setAuthor(String author) {

	}

	public String getDescription() {
		return null;
	}

	public void setDescription(String description) {
		
	}

	public Date getPublishedAt() {
		return null;
	}

	public void setPublishedAt() {
		
	}

	public String getContent() {
		return null;
	}

	public void setContent(String content) {
		
	}

	public String getUrl() {
		return null;
	}

	public void setUrl(String url) {
		
	}

	public String getUrlToImage() {
		return null;
	}

	public void setUrlToImage(String urlToImage) {
		
	}

	public NewsSource getNewsSource() {
		return null;
	}

	public void setNewssource(NewsSource newsSource) {

	}


}
